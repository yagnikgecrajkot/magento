<?php

class Yagnik_Eavmgmt_Block_Eavmgmt extends Mage_Core_Block_Template
{
    function __construct()
    {
        parent::__construct();
    }

}
